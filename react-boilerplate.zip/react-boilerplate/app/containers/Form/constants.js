/*
 *
 * Form constants
 *
 */

export const DEFAULT_ACTION = 'app/Form/DEFAULT_ACTION';
